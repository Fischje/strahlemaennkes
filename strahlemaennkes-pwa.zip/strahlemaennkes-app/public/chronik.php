<?php
$pageTitle = 'Chronik';
$publicPage = true;
require __DIR__ . '/../includes/header.php';
?>
<section class="hero py-5">
  <div class="container"><div class="eyebrow">Öffentlich</div><h1 class="section-title display-4">Chronik der Strahlemännkes</h1><p class="lead">Ämter und besondere Würdenträger unseres Zuges – Jahr für Jahr dokumentiert.</p></div>
</section>
<section class="py-5">
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-8">
        <div class="panel p-4 p-md-5">
          <div class="timeline-row pb-5"><div class="chronik-year">2026</div><h3 class="h5 mt-2">Zugjahr 2026</h3><div class="row row-cols-1 row-cols-sm-2 g-2 mt-2"><div class="col"><span class="text-secondary">Zugkönig</span><br><strong>Beispielname</strong></div><div class="col"><span class="text-secondary">Zugführer</span><br><strong>Beispielname</strong></div><div class="col"><span class="text-secondary">Kassierer</span><br><strong>Beispielname</strong></div><div class="col"><span class="text-secondary">Schriftführer</span><br><strong>Beispielname</strong></div><div class="col"><span class="text-secondary">1. Offizier</span><br><strong>Beispielname</strong></div><div class="col"><span class="text-secondary">2. Offizier</span><br><strong>Beispielname</strong></div></div></div>
          <div class="timeline-row"><div class="chronik-year">2025</div><h3 class="h5 mt-2">Zugjahr 2025</h3><p class="text-secondary mb-0">Weitere Jahrgänge werden später über den internen Bereich gepflegt.</p></div>
        </div>
      </div>
      <div class="col-lg-4"><div class="panel p-4"><h2 class="h5 fw-bold">Über die Chronik</h2><p class="text-secondary mb-0">Diese Seite bleibt öffentlich und funktioniert unabhängig vom internen Mitgliederbereich. Später können Bilder, Jubiläen und besondere Ereignisse pro Jahr ergänzt werden.</p></div></div>
    </div>
  </div>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>
