<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax', 'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')]);
    session_start();
}
require_once __DIR__ . '/db.php';

function e(?string $value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function redirect(string $path): never { header('Location: ' . $path); exit; }
function flash(string $type, string $message): void { $_SESSION['flash'][] = compact('type','message'); }
function flashes(): array { $f = $_SESSION['flash'] ?? []; unset($_SESSION['flash']); return $f; }
function csrf_token(): string { if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function verify_csrf(): void { if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) { http_response_code(419); exit('Ungültige oder abgelaufene Anfrage.'); } }
function current_user(): ?array { return $_SESSION['user'] ?? null; }
function login_user(array $user): void { session_regenerate_id(true); $_SESSION['user'] = ['id'=>(int)$user['id'],'username'=>$user['username'],'first_name'=>$user['first_name'],'last_name'=>$user['last_name'],'role'=>$user['role']]; }
function require_login(): array { $u=current_user(); if(!$u){ flash('warning','Bitte zuerst anmelden.'); redirect('/login.php'); } return $u; }
function has_role(string ...$roles): bool { $u=current_user(); return $u && in_array($u['role'],$roles,true); }
function require_role(string ...$roles): array { $u=require_login(); if(!in_array($u['role'],$roles,true)){ http_response_code(403); exit('Keine Berechtigung.'); } return $u; }
function role_label(string $role): string { return ['member'=>'Mitglied','spiess'=>'Spieß / Moderator','admin'=>'Administrator'][$role] ?? $role; }
