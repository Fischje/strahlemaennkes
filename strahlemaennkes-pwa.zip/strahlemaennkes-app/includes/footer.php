<?php $footerUser = current_user(); ?>
</main>
<?php if($footerUser): ?>
<nav class="mobile-bottom-nav d-lg-none" aria-label="App-Navigation">
  <a href="/dashboard.php" class="<?= str_contains($_SERVER['REQUEST_URI'] ?? '', 'dashboard.php') ? 'active' : '' ?>"><i class="bi bi-house-door"></i><span>Start</span></a>
  <a href="/member-drink.php" class="<?= str_contains($_SERVER['REQUEST_URI'] ?? '', 'member-drink.php') ? 'active' : '' ?>"><i class="bi bi-cup-straw"></i><span>Getränk</span></a>
  <?php if(has_role('spiess','admin')): ?>
    <a href="/theke.php" class="<?= str_contains($_SERVER['REQUEST_URI'] ?? '', 'theke.php') ? 'active' : '' ?>"><i class="bi bi-list-check"></i><span>Theke</span></a>
    <a href="/drinks.php" class="<?= str_contains($_SERVER['REQUEST_URI'] ?? '', 'drinks.php') ? 'active' : '' ?>"><i class="bi bi-sliders"></i><span>Verwalten</span></a>
  <?php else: ?>
    <a href="/public/chronik.php" class="<?= str_contains($_SERVER['REQUEST_URI'] ?? '', '/public/chronik.php') ? 'active' : '' ?>"><i class="bi bi-book"></i><span>Chronik</span></a>
    <a href="/logout.php"><i class="bi bi-box-arrow-right"></i><span>Logout</span></a>
  <?php endif; ?>
</nav>
<?php endif; ?>
<footer class="app-footer py-4 mt-5"><div class="container d-flex flex-column flex-md-row justify-content-between gap-2 small"><span>© <?= date('Y') ?> Schützenzug „Strahlemännkes“</span><span>St. Maria Männerbruderschaft Bettrath</span></div></footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<script src="/assets/js/app.js"></script>
</body></html>
