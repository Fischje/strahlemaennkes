<?php
require_once __DIR__ . '/app.php';
$pageTitle = $pageTitle ?? 'Strahlemännkes';
$u = current_user();
$currentPath = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
?>
<!doctype html>
<html lang="de">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <meta name="theme-color" content="#b5121b">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <meta name="apple-mobile-web-app-title" content="Strahlemännkes">
  <meta name="description" content="Interne Zug-App der Strahlemännkes – Getränke, Strafen und Organisation.">
  <title><?= e($pageTitle) ?> · Strahlemännkes</title>
  <link rel="manifest" href="/manifest.webmanifest">
  <link rel="icon" href="/assets/icons/icon-192.png" sizes="192x192">
  <link rel="apple-touch-icon" href="/assets/icons/apple-touch-icon.png">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="/assets/css/app.css">
</head>
<body class="<?= $u ? 'has-mobile-nav' : '' ?>">
<nav class="navbar navbar-expand-lg navbar-dark app-navbar sticky-top">
  <div class="container">
    <a class="navbar-brand d-flex align-items-center gap-2" href="<?= $u ? '/dashboard.php' : '/index.php' ?>">
      <span class="brand-mark">SM</span>
      <span><strong>Strahlemännkes</strong><small>St. Maria Männerbruderschaft Bettrath</small></span>
    </a>
    <div class="d-flex align-items-center gap-2 ms-auto d-lg-none">
      <?php if ($u): ?><span class="online-dot" data-online-indicator title="Verbindungsstatus"></span><?php endif; ?>
      <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-label="Menü öffnen"><span class="navbar-toggler-icon"></span></button>
    </div>
    <div class="collapse navbar-collapse" id="mainNav">
      <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-1 py-2 py-lg-0">
        <li class="nav-item"><a class="nav-link" href="/public/chronik.php">Chronik</a></li>
        <?php if($u): ?>
          <li class="nav-item"><a class="nav-link" href="/dashboard.php">Übersicht</a></li>
          <li class="nav-item"><a class="nav-link" href="/member-drink.php">Mein Getränk</a></li>
          <?php if(has_role('spiess','admin')): ?>
            <li class="nav-item"><a class="nav-link" href="/theke.php">Theke</a></li>
            <li class="nav-item"><a class="nav-link" href="/drinks.php">Getränke verwalten</a></li>
          <?php endif; ?>
          <?php if(has_role('admin')): ?><li class="nav-item"><a class="nav-link" href="/members.php">Benutzer</a></li><?php endif; ?>
          <li class="nav-item ms-lg-2"><a class="btn btn-light btn-sm px-3" href="/logout.php"><i class="bi bi-box-arrow-right me-1"></i> Logout</a></li>
        <?php else: ?>
          <li class="nav-item ms-lg-2"><a class="btn btn-light btn-sm px-3" href="/login.php"><i class="bi bi-person-circle me-1"></i> Login</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
<main>
<?php foreach(flashes() as $f): ?>
  <div class="container mt-3"><div class="alert alert-<?= e($f['type']) ?> alert-dismissible fade show shadow-sm" role="alert"><?= e($f['message']) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div></div>
<?php endforeach; ?>
