<?php
function send_drink_push(PDO $pdo, array $config, string $target, string $message): array {
    $vendor = __DIR__ . '/../vendor/autoload.php';
    if (!is_file($vendor) || empty($config['push']['public_key']) || empty($config['push']['private_key'])) {
        return ['sent'=>0,'failed'=>0,'configured'=>false];
    }
    require_once $vendor;
    $sql = "SELECT ps.* FROM push_subscriptions ps JOIN users u ON u.id=ps.user_id LEFT JOIN user_drink_preferences p ON p.user_id=u.id WHERE u.is_active=1";
    if ($target === 'members_without_choice') $sql .= " AND p.drink_id IS NULL";
    $subs = $pdo->query($sql)->fetchAll();
    $auth = ['VAPID'=>['subject'=>$config['push']['subject'],'publicKey'=>$config['push']['public_key'],'privateKey'=>$config['push']['private_key']]];
    $webPush = new \Minishlink\WebPush\WebPush($auth);
    $payload = json_encode(['title'=>'Strahlemännkes · Getränkerunde','body'=>$message,'url'=>'/member-drink.php'], JSON_UNESCAPED_UNICODE);
    foreach ($subs as $sub) {
        $subscription = \Minishlink\WebPush\Subscription::create(['endpoint'=>$sub['endpoint'],'publicKey'=>$sub['p256dh'],'authToken'=>$sub['auth_token']]);
        $webPush->queueNotification($subscription, $payload, ['TTL'=>3600,'urgency'=>'high']);
    }
    $sent=0; $failed=0;
    foreach ($webPush->flush() as $report) {
        if ($report->isSuccess()) { $sent++; }
        else { $failed++; if ($report->isSubscriptionExpired()) { $st=$pdo->prepare('DELETE FROM push_subscriptions WHERE endpoint=?'); $st->execute([$report->getEndpoint()]); } }
    }
    return ['sent'=>$sent,'failed'=>$failed,'configured'=>true];
}
