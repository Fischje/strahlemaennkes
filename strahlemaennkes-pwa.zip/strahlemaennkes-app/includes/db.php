<?php
$config = require __DIR__ . '/../config.php';
$dbPath = $config['db']['path'];
$dbDir = dirname($dbPath);

if (!is_dir($dbDir) && !mkdir($dbDir, 0775, true) && !is_dir($dbDir)) {
    http_response_code(500);
    exit('Datenverzeichnis konnte nicht angelegt werden.');
}

try {
    $pdo = new PDO('sqlite:' . $dbPath, null, null, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);

    // Sinnvolle SQLite-Einstellungen für eine kleine Web-App mit mehreren gleichzeitigen Zugriffen.
    $pdo->exec('PRAGMA foreign_keys = ON');
    $pdo->exec('PRAGMA busy_timeout = 5000');
    $pdo->exec('PRAGMA journal_mode = WAL');

    require_once __DIR__ . '/migrate.php';
    run_migrations($pdo, __DIR__ . '/../migrations');
} catch (Throwable $e) {
    http_response_code(500);
    exit('Lokale Datenbank konnte nicht geöffnet oder aktualisiert werden: ' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8'));
}
