<?php
require_once __DIR__ . '/../includes/app.php';
require_role('spiess','admin');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
$rows = $pdo->query("SELECT d.id,d.name,d.emoji,COUNT(*) qty,GROUP_CONCAT(u.first_name || ' ' || substr(u.last_name,1,1) || '.', '|||') members FROM users u JOIN user_drink_preferences p ON p.user_id=u.id JOIN drinks d ON d.id=p.drink_id WHERE u.is_active=1 GROUP BY d.id,d.name,d.emoji ORDER BY qty DESC,d.name COLLATE NOCASE")->fetchAll();
$total=(int)$pdo->query('SELECT COUNT(*) FROM users WHERE is_active=1')->fetchColumn();
$chosen=array_sum(array_map(fn($r)=>(int)$r['qty'],$rows));
foreach($rows as &$r){$r['qty']=(int)$r['qty'];$r['members']=$r['members'] ? explode('|||',$r['members']) : [];}
unset($r);
echo json_encode(['updated_at'=>date('H:i:s'),'total'=>$total,'chosen'=>$chosen,'none'=>max(0,$total-$chosen),'drinks'=>$rows],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
