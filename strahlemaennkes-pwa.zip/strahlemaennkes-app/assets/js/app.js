window.SM = window.SM || {};
SM.urlBase64ToUint8Array = function(base64String){const padding='='.repeat((4-base64String.length%4)%4);const base64=(base64String+padding).replace(/-/g,'+').replace(/_/g,'/');const raw=atob(base64);return Uint8Array.from([...raw].map(c=>c.charCodeAt(0)));};

SM.enablePush = async function(publicKey){
  if(!('serviceWorker' in navigator) || !('PushManager' in window)) throw new Error('Browser unterstützt Web-Push nicht.');
  if(!publicKey) throw new Error('Push ist auf dem Server noch nicht vollständig konfiguriert.');
  const reg=await navigator.serviceWorker.ready;
  const permission=await Notification.requestPermission();
  if(permission!=='granted') throw new Error('Benachrichtigungen wurden nicht erlaubt.');
  let sub=await reg.pushManager.getSubscription();
  if(!sub) sub=await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:SM.urlBase64ToUint8Array(publicKey)});
  const res=await fetch('/push-subscribe.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(sub)});
  if(!res.ok) throw new Error('Push-Abo konnte nicht gespeichert werden.');
  return true;
};

SM.isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent);
SM.isStandalone = window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
SM.deferredInstallPrompt = null;

window.addEventListener('beforeinstallprompt', (event) => {
  event.preventDefault();
  SM.deferredInstallPrompt = event;
  document.querySelectorAll('[data-pwa-install]').forEach(el => el.hidden = false);
});
window.addEventListener('appinstalled', () => {
  SM.deferredInstallPrompt = null;
  document.querySelectorAll('[data-pwa-install]').forEach(el => el.hidden = true);
});

SM.installPwa = async function(){
  if(SM.isStandalone) return {installed:true};
  if(SM.deferredInstallPrompt){
    SM.deferredInstallPrompt.prompt();
    const result = await SM.deferredInstallPrompt.userChoice;
    if(result.outcome === 'accepted') SM.deferredInstallPrompt = null;
    return {installed: result.outcome === 'accepted'};
  }
  if(SM.isIOS){
    alert('Auf dem iPhone: unten auf „Teilen“ tippen und anschließend „Zum Home-Bildschirm“ wählen.');
    return {installed:false};
  }
  alert('Öffne das Browser-Menü und wähle „App installieren“ oder „Zum Startbildschirm hinzufügen“.');
  return {installed:false};
};

SM.setOnlineState = function(){
  document.querySelectorAll('[data-online-indicator]').forEach(el => el.classList.toggle('offline', !navigator.onLine));
};

SM.enableWakeLock = async function(button){
  if(!('wakeLock' in navigator)) { alert('Dein Browser unterstützt das Wachhalten des Displays nicht.'); return; }
  try {
    if(SM.wakeLock){ await SM.wakeLock.release(); SM.wakeLock=null; button.classList.remove('active'); button.innerHTML='<i class="bi bi-lightbulb me-1"></i> Display wach'; return; }
    SM.wakeLock=await navigator.wakeLock.request('screen');
    button.classList.add('active'); button.innerHTML='<i class="bi bi-lightbulb-fill me-1"></i> Display bleibt wach';
    SM.wakeLock.addEventListener('release',()=>{button.classList.remove('active');});
  } catch(e){ alert('Display konnte nicht wach gehalten werden.'); }
};

document.addEventListener('DOMContentLoaded', () => {
  if('serviceWorker' in navigator) navigator.serviceWorker.register('/service-worker.js').catch(()=>{});
  SM.setOnlineState();
  window.addEventListener('online', SM.setOnlineState);
  window.addEventListener('offline', SM.setOnlineState);
  document.querySelectorAll('[data-pwa-install]').forEach(btn => {
    if(SM.isStandalone) btn.hidden = true;
    else if(SM.isIOS) btn.hidden = false;
    btn.addEventListener('click', SM.installPwa);
  });
  document.querySelectorAll('[data-wake-lock]').forEach(btn => btn.addEventListener('click',()=>SM.enableWakeLock(btn)));
});
